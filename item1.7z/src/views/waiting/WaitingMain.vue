<template>
  <div class="mainContent ">
    <el-card>
      <div class="mainHeader">
        <!-- <el-link :underline="false"
                 v-for="(item,index) in titleContent"
                 :key="index">{{item}}</el-link> -->
        <el-row>
          <el-button round
                     v-for="item in bntForm"
                     :key='item.id'>
            <i :class="item.i"></i>
            {{item.btnName}}
          </el-button>
        </el-row>
      </div>
      <waiting-item></waiting-item>
    </el-card>
  </div>
</template>

<script>
import WaitingItem from './WaitingItem.vue'
export default {
  data() {
    return {
      titleContent: ['关注', '推荐', '热榜', '视频'],
      bntForm: [
        {
          id: '1',
          i: 'el-icon-arrow-down',
          btnName: '为你推荐',
        },
        {
          id: '2',
          i: 'el-icon-arrow-down',
          btnName: '为你推荐',
        },
        {
          id: '3',
          i: 'el-icon-arrow-down',
          btnName: '为你推荐',
        },
        {
          id: '4',
          i: 'el-icon-arrow-down',
          btnName: '为你推荐',
        },
      ],
    }
  },
  components: {
    WaitingItem,
  },
}
</script>

<style lang="less" scoped>
.mainContent {
  background-color: #fff;
  margin-top: 15px;
  .mainHeader {
    box-sizing: border-box;
    height: 59px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #e3e4e5;
    // padding: 10px;
    .el-link {
      margin: 0 15px;
    }
    .el-button {
      margin-right: 10px;
    }
  }
}
</style>