<template>
  <div>
    <header-title :activeIndex='activeIndex'></header-title>
  </div>
</template>

<script>
import HeaderTitle from './home/Header.vue'
export default {
  data() {
    return {
      activeIndex: '2',
    }
  },
  components: {
    HeaderTitle,
  },
}
</script>

<style lang="less" scoped>
</style>