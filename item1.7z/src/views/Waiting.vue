<template>
  <div>
    <!-- 头部 -->
    <header-title :activeIndex='activeIndex'></header-title>
    <!-- 主体 -->
    <div class="model">
      <div class="mainContent">
        <!-- 左边 -->
        <div>
          <waiting-main></waiting-main>
        </div>
        <!-- 右边 -->
        <main-right></main-right>
      </div>
    </div>
  </div>
</template>

<script>
import HeaderTitle from './home/Header.vue'
import WaitingMain from './waiting/WaitingMain.vue'
import MainRight from './home/main/MainRight.vue'
export default {
  data() {
    return {
      activeIndex: '4',
    }
  },
  components: {
    HeaderTitle,
    WaitingMain,
    MainRight,
  },
}
</script>

<style lang="less" scoped>
.mainContent {
  float: left;
}
</style>